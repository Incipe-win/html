# loveyue
loveyue系列1到8的源码
这个网页里有一点点解释，只针对没有网站基础的人，什么都不会的，可以看看这个：<a href='http://loveyue1.sinaapp.com/love/index.html' target="_blank">http://loveyue1.sinaapp.com/love/index.html</a>
