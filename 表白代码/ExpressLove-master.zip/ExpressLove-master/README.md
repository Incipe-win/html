# 轻松搞定表白女朋友APP

本软件的主要目的是用来表白女朋友，让女朋友开心，欢迎大家修改做出更好的效果，同时也十分欢迎大家star和Pull requests，github开源库链接是：
https://github.com/Geeksongs/ExpressLove

 软件的效果如下：

![image](https://github.com/Geeksongs/ExpressLove/blob/master/yanshi.gif)

