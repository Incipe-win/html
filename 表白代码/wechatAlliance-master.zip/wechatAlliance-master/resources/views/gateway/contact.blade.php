@extends('layouts/gateway')
<style>
    .wechat-image{
        width: 150px;
        height: 150px;
    }
</style>
@section('content')
    <div class="container">
        <div class="jumbotron">
            <div>
                <image class="wechat-image" src="http://image.kucaroom.com/微信图片_20180518162032.jpg"></image>
            </div>
            <p>微信号：13425144866</p>
        </div>
    </div>
@stop